This dataset is created by Ali Pashaei, Mehdi Ghatee and Hedieh Sajedi. 
The first and the second are with Department of Computer Science, Amirkabir University of Technology, Tehran, Iran.
The third is with Department of Mathematics, Statistics and Computer Science, College of Science, University of Tehran, Tehran, Iran
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
The aim of this dataset is to detect the occurrence of accidents, by image processing.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
This folder includes two subfolders with labels "without-accident" and "with-accident". 
Folder 1 includes 2500 images with label "without-accident".
Folder 2 includes 2398 images with label "with-accident".
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
In case of using this dataset for any research and/or application, please refer to the following paper:

Ali Pashaei, Mehdi Ghatee, Hedieh Sajedi, Convolution Neural Network Joint with Mixture of Extreme Learning Machines for Feature Extraction and Classification of Accident Images,
Journal of Real-Time Image Processing, 2019.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++