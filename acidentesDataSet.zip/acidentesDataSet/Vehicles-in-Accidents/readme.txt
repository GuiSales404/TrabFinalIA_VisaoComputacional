This dataset is created by Ali Pashaei, Mehdi Ghatee and Hedieh Sajedi. 
The first and the second are with Department of Computer Science, Amirkabir University of Technology, Tehran, Iran.
The third is with Department of Mathematics, Statistics and Computer Science, College of Science, University of Tehran, Tehran, Iran
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
The aim of this dataset is to classify the vehicles involved in an accident, by image processing.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
The aim of this dataset is to classify the vehicles involved in an accident, by image processing. It includes three subfolders with labels "light vehicle", "heavy vehicle" and "motorcycle".
Folder 1 includes 892 images with label "light vehicle".
Folder 2 includes 876 images with label "heavy vehicle".
Folder 3 includes 868 images with label "motorcycle".

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
In case of using this dataset for any research and/or application, please refer to the following paper:

Ali Pashaei, Mehdi Ghatee, Hedieh Sajedi, Convolution Neural Network Joint with Mixture of Extreme Learning Machines for Feature Extraction and Classification of Accident Images,
Journal of Real-Time Image Processing, 2019.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++